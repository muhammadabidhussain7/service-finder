import React, { useEffect, useState } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { StatusBar } from 'expo-status-bar';
import { AppProvider, useApp } from './src/context/AppContext';
import { RootNavigator } from './src/navigation/RootNavigator';
import { colors } from './src/theme';

function AppShell() {
  const { ready, darkMode } = useApp();
  if (!ready) return <View style={{flex:1,alignItems:'center',justifyContent:'center',backgroundColor:colors.green}}><ActivityIndicator color="#fff" size="large" /></View>;
  return (
    <NavigationContainer>
      <StatusBar style={darkMode ? 'light' : 'dark'} />
      <RootNavigator />
    </NavigationContainer>
  );
}

export default function App() {
  return <AppProvider><AppShell /></AppProvider>;
}
