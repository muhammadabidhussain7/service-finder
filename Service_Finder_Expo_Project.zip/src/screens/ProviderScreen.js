import React from 'react';
import {View,Text,Image,ScrollView,Pressable,StyleSheet,Alert} from 'react-native';
import {useApp} from '../context/AppContext';
import {callNumber,openWhatsApp} from '../utils/contact';
export function ProviderScreen({route,navigation}){
 const {provider:p}=route.params;const {toggleFavourite,isFavourite}=useApp();const saved=isFavourite(p.id);
 return <ScrollView style={s.screen} contentContainerStyle={{padding:18}}>
  <Image source={{uri:p.photo||'https://placehold.co/600x400'}} style={s.photo}/>
  <View style={s.titleRow}><View style={{flex:1}}><Text style={s.name}>{p.name}</Text><Text style={s.sub}>{p.category} · {p.city}</Text></View><Pressable onPress={()=>toggleFavourite(p.id)}><Text style={s.heart}>{saved?'♥':'♡'}</Text></Pressable></View>
  <Text style={s.rating}>★ {Number(p.rating||0).toFixed(1)} · {p.reviews||0} reviews {p.verified?'· ✓ Verified':''}</Text>
  <View style={s.stats}><View><Text style={s.statValue}>{p.experience} yrs</Text><Text style={s.sub}>Experience</Text></View><View><Text style={s.statValue}>{p.price||'Ask'}</Text><Text style={s.sub}>Price range</Text></View><View><Text style={s.statValue}>{p.area}</Text><Text style={s.sub}>Service area</Text></View></View>
  <Text style={s.heading}>About this provider</Text><Text style={s.body}>{p.description||'Contact this provider for more details about their services.'}</Text>
  <Text style={s.heading}>Customer reviews</Text><Text style={s.body}>{p.reviews||0} customer ratings. Reviews will appear here as customers submit feedback.</Text>
  <Pressable style={s.review} onPress={()=>navigation.navigate('Review',{provider:p})}><Text style={s.reviewText}>＋ Write a review</Text></Pressable>
  <View style={s.buttons}><Pressable style={s.call} onPress={()=>callNumber(p.phone)}><Text style={s.buttonText}>☎  Call</Text></Pressable><Pressable style={s.whatsapp} onPress={()=>openWhatsApp(p.phone)}><Text style={s.buttonText}>WhatsApp</Text></Pressable></View>
 </ScrollView>
}
const s=StyleSheet.create({screen:{flex:1,backgroundColor:'#F6F8F7'},photo:{width:'100%',height:210,borderRadius:20,backgroundColor:'#E8F5EF'},titleRow:{flexDirection:'row',alignItems:'center',marginTop:18},name:{fontSize:24,fontWeight:'900',color:'#17221D'},sub:{color:'#718078',marginTop:5,fontSize:13},heart:{fontSize:30,color:'#087F5B'},rating:{color:'#B7791F',fontWeight:'800',marginTop:12},stats:{backgroundColor:'#fff',borderRadius:17,padding:15,flexDirection:'row',justifyContent:'space-between',marginTop:18,borderWidth:1,borderColor:'#E2EAE5'},statValue:{fontWeight:'900',color:'#087F5B',fontSize:14},heading:{fontSize:18,fontWeight:'900',color:'#17221D',marginTop:24,marginBottom:8},body:{color:'#526158',lineHeight:22},review:{padding:14,borderRadius:13,borderWidth:1,borderColor:'#087F5B',marginTop:15,alignItems:'center'},reviewText:{color:'#087F5B',fontWeight:'800'},buttons:{flexDirection:'row',gap:12,marginTop:18,marginBottom:20},call:{flex:1,backgroundColor:'#087F5B',padding:16,borderRadius:14,alignItems:'center'},whatsapp:{flex:1,backgroundColor:'#25D366',padding:16,borderRadius:14,alignItems:'center'},buttonText:{color:'#fff',fontWeight:'900'}});
