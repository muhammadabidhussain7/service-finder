export const countries = [
  { name:'Pakistan', flag:'🇵🇰', provinces:['Sindh','Punjab','Khyber Pakhtunkhwa','Balochistan','Gilgit-Baltistan','Azad Jammu and Kashmir','Islamabad Capital Territory'] },
  { name:'United Arab Emirates', flag:'🇦🇪', provinces:['Abu Dhabi','Dubai','Sharjah','Ajman'] },
  { name:'Saudi Arabia', flag:'🇸🇦', provinces:['Riyadh','Makkah','Madinah','Eastern Province'] },
  { name:'United Kingdom', flag:'🇬🇧', provinces:['England','Scotland','Wales','Northern Ireland'] },
  { name:'United States', flag:'🇺🇸', provinces:['California','Texas','New York','Florida'] }
];

export const citiesByProvince = {
  'Sindh':['Karachi','Hyderabad','Sukkur','Larkana','Nawabshah (Shaheed Benazirabad)','Mirpur Khas','Jacobabad','Shikarpur','Khairpur','Thatta','Badin','Dadu','Umerkot','Ghotki','Kashmore'],
  'Punjab':['Lahore','Rawalpindi','Faisalabad','Multan','Gujranwala','Sialkot','Bahawalpur','Sargodha','Sahiwal','Sheikhupura','Jhelum','Rahim Yar Khan','Gujrat','Dera Ghazi Khan','Kasur','Okara'],
  'Khyber Pakhtunkhwa':['Peshawar','Mardan','Abbottabad','Swat (Mingora)','Kohat','Dera Ismail Khan','Mansehra','Charsadda','Nowshera','Bannu','Haripur'],
  'Balochistan':['Quetta','Gwadar','Turbat','Khuzdar','Chaman','Sibi','Zhob','Hub','Loralai'],
  'Gilgit-Baltistan':['Gilgit','Skardu','Hunza','Ghanche','Ghizer','Astore'],
  'Azad Jammu and Kashmir':['Muzaffarabad','Mirpur','Kotli','Rawalakot','Bhimber','Bagh'],
  'Islamabad Capital Territory':['Islamabad'],
  'Abu Dhabi':['Abu Dhabi','Al Ain','Madinat Zayed'],
  'Dubai':['Dubai','Hatta'],
  'Sharjah':['Sharjah','Khor Fakkan'],
  'Ajman':['Ajman'],
  'Riyadh':['Riyadh','Al Kharj'],
  'Makkah':['Makkah','Jeddah','Taif'],
  'Madinah':['Madinah','Yanbu'],
  'Eastern Province':['Dammam','Khobar','Jubail'],
  'England':['London','Manchester','Birmingham','Leeds','Liverpool'],
  'Scotland':['Edinburgh','Glasgow','Aberdeen'],
  'Wales':['Cardiff','Swansea'],
  'Northern Ireland':['Belfast','Derry'],
  'California':['Los Angeles','San Diego','San Francisco'],
  'Texas':['Houston','Dallas','Austin'],
  'New York':['New York City','Buffalo'],
  'Florida':['Miami','Orlando','Tampa']
};
