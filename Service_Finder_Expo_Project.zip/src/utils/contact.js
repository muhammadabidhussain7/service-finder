import { Linking, Alert } from 'react-native';
export async function callNumber(phone) {
  const url = `tel:${phone}`;
  if (await Linking.canOpenURL(url)) await Linking.openURL(url);
  else Alert.alert('Unable to call','Calling is not available on this device.');
}
export async function openWhatsApp(phone) {
  const url = `https://wa.me/${String(phone).replace(/\D/g,'')}`;
  const ok = await Linking.canOpenURL(url);
  if (ok) await Linking.openURL(url);
  else Alert.alert('WhatsApp unavailable','Please install WhatsApp or try calling.');
}
