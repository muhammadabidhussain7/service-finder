import React,{useMemo,useState} from 'react';
import {View,Text,TextInput,FlatList,Pressable,StyleSheet,SafeAreaView} from 'react-native';
import {countries,citiesByProvince} from '../data/locations';
import {useApp} from '../context/AppContext';

export function LocationFlowScreen({navigation}){
 const {setLocation,location}=useApp();
 const [step,setStep]=useState(0),[country,setCountry]=useState('Pakistan'),[province,setProvince]=useState('Sindh'),[city,setCity]=useState('Karachi'),[search,setSearch]=useState('');
 const selectedCountry=countries.find(c=>c.name===country)||countries[0];
 const items=useMemo(()=>{
  const list=step===0?countries:step===1?selectedCountry.provinces.map(name=>({name})): (citiesByProvince[province]||['Capital City']).map(name=>({name}));
  return list.filter(x=>x.name.toLowerCase().includes(search.toLowerCase()));
 },[step,country,province,search]);
 const current=step===0?country:step===1?province:city;
 const choose=(name)=>{if(step===0){setCountry(name);setProvince(countries.find(c=>c.name===name)?.provinces[0]||'');setCity('');}else if(step===1){setProvince(name);setCity((citiesByProvince[name]||[])[0]||'');}else setCity(name);};
 const next=()=>{if(step<2){setStep(step+1);setSearch('');}else{setLocation({country,province,city});navigation.reset({index:0,routes:[{name:'Main'}]});}};
 return <SafeAreaView style={s.screen}><View style={s.wrap}>
  <Text style={s.brand}>📍 Service Finder</Text><Text style={s.title}>{['Choose your country','Choose your province / state','Choose your city'][step]}</Text>
  <Text style={s.sub}>Step {step+1} of 3 · Set your location to find nearby professionals.</Text>
  <View style={s.progress}><View style={[s.progressFill,{width:`${(step+1)*33.333}%`}]} /></View>
  <TextInput value={search} onChangeText={setSearch} placeholder="Search..." placeholderTextColor="#84928A" style={s.search}/>
  <FlatList data={items} keyExtractor={x=>x.name} keyboardShouldPersistTaps="handled" renderItem={({item})=>{
   const flag=step===0?item.flag+'  ':'';
   return <Pressable onPress={()=>choose(item.name)} style={[s.option,current===item.name&&s.selected]}><Text style={s.optionText}>{flag}{item.name}</Text><Text style={s.radio}>{current===item.name?'●':'○'}</Text></Pressable>
  }}/>
  <View style={s.actions}>{step>0&&<Pressable style={s.back} onPress={()=>{setStep(step-1);setSearch('')}}><Text style={s.backText}>Back</Text></Pressable>}<Pressable disabled={!current} onPress={next} style={[s.continue,!current&&{opacity:.45}]}><Text style={s.continueText}>{step===2?'Save location':'Continue'}</Text></Pressable></View>
 </View></SafeAreaView>
}
const s=StyleSheet.create({screen:{flex:1,backgroundColor:'#F6F8F7'},wrap:{flex:1,padding:22},brand:{fontSize:17,color:'#087F5B',fontWeight:'900',marginTop:20},title:{fontSize:27,fontWeight:'900',color:'#17221D',marginTop:28},sub:{color:'#718078',marginTop:8,lineHeight:20},progress:{height:7,backgroundColor:'#DCE9E1',borderRadius:10,marginVertical:22,overflow:'hidden'},progressFill:{height:7,backgroundColor:'#087F5B'},search:{height:50,borderRadius:14,backgroundColor:'#fff',paddingHorizontal:15,borderWidth:1,borderColor:'#E2EAE5',marginBottom:12,color:'#17221D'},option:{padding:16,backgroundColor:'#fff',borderRadius:14,marginBottom:8,flexDirection:'row',justifyContent:'space-between',alignItems:'center',borderWidth:1,borderColor:'#E2EAE5'},selected:{borderColor:'#087F5B',backgroundColor:'#E8F5EF'},optionText:{fontSize:15,color:'#17221D',fontWeight:'600'},radio:{color:'#087F5B',fontSize:18},actions:{flexDirection:'row',gap:10,paddingVertical:12},back:{padding:16,borderRadius:14,borderWidth:1,borderColor:'#087F5B'},backText:{color:'#087F5B',fontWeight:'800'},continue:{flex:1,padding:16,borderRadius:14,backgroundColor:'#087F5B',alignItems:'center'},continueText:{color:'#fff',fontWeight:'900'}}
);
