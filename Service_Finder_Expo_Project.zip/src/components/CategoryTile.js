import React from 'react';
import { Pressable, Text, StyleSheet } from 'react-native';
export function CategoryTile({item,onPress}) {
 return <Pressable onPress={onPress} style={s.tile}><Text style={s.icon}>{item.icon}</Text><Text style={s.label}>{item.name}</Text></Pressable>
}
const s=StyleSheet.create({tile:{width:'31%',minHeight:98,backgroundColor:'#fff',borderRadius:18,alignItems:'center',justifyContent:'center',padding:10,borderWidth:1,borderColor:'#E6EDE8',marginBottom:10},icon:{fontSize:27,marginBottom:8},label:{fontSize:12,fontWeight:'700',color:'#24332B',textAlign:'center'}});
