export const colors = {
  green: '#087F5B',
  greenDark: '#056447',
  mint: '#E8F5EF',
  background: '#F6F8F7',
  card: '#FFFFFF',
  text: '#17221D',
  muted: '#718078',
  border: '#E2EAE5',
  danger: '#C0392B',
  gold: '#E6A23C'
};
export const darkColors = {
  ...colors, background:'#101815', card:'#19231E', text:'#F1F7F3',
  muted:'#A2B1A8', border:'#2B3A32', mint:'#20382D'
};
