import { collection, getDocs, addDoc, query, where, orderBy } from 'firebase/firestore';
import { db, firebaseConfigured } from './firebase';
import { demoProviders } from '../data/demoProviders';

export async function getProviders(city, category) {
  if (!firebaseConfigured) return demoProviders.filter(p => (!city || p.city === city) && (!category || p.category === category));
  let q = collection(db, 'providers');
  const constraints = [where('status','==','approved')];
  if (city) constraints.push(where('city','==',city));
  if (category) constraints.push(where('category','==',category));
  const snap = await getDocs(query(q, ...constraints));
  return snap.docs.map(d => ({id:d.id,...d.data()}));
}
export async function submitProvider(data) {
  if (!firebaseConfigured) throw new Error('Firebase is not configured. Add your Firebase settings to .env to submit provider registrations online.');
  return addDoc(collection(db,'providers'), {...data,status:'pending',createdAt:new Date().toISOString()});
}
