import React,{useEffect,useState} from 'react';
import {View,Text,FlatList,Pressable,StyleSheet,ActivityIndicator} from 'react-native';
import {useApp} from '../context/AppContext';
import {getProviders} from '../services/providers';
import {ProviderCard} from '../components/ProviderCard';
import {categories} from '../data/categories';

export function CategoryScreen({route,navigation}){
 const {location}=useApp(); const category=route.params?.category; const search=route.params?.search||'';
 const [items,setItems]=useState([]),[loading,setLoading]=useState(true),[sort,setSort]=useState('rating'),[verified,setVerified]=useState(false);
 useEffect(()=>{let active=true;(async()=>{try{const p=await getProviders(location?.city,category?.id);if(active)setItems(p.filter(x=>!search||x.name.toLowerCase().includes(search.toLowerCase())||x.description?.toLowerCase().includes(search.toLowerCase())));}catch(e){}finally{if(active)setLoading(false)}})();return()=>{active=false}},[location,category,search]);
 const data=[...items].filter(x=>!verified||x.verified).sort((a,b)=>sort==='rating'?b.rating-a.rating:sort==='newest'?String(b.createdAt||'').localeCompare(String(a.createdAt||'')):0);
 return <View style={s.screen}>
  <Text style={s.heading}>{category?.name||'All service providers'}</Text>
  <View style={s.filters}>{[['rating','Top rated'],['newest','Newest']].map(([v,l])=><Pressable key={v} onPress={()=>setSort(v)} style={[s.chip,sort===v&&s.active]}><Text style={[s.chipText,sort===v&&s.activeText]}>{l}</Text></Pressable>)}<Pressable onPress={()=>setVerified(!verified)} style={[s.chip,verified&&s.active]}><Text style={[s.chipText,verified&&s.activeText]}>✓ Verified</Text></Pressable></View>
  {loading?<ActivityIndicator color="#087F5B" style={{marginTop:40}}/>:<FlatList data={data} keyExtractor={x=>x.id} contentContainerStyle={{padding:16}} renderItem={({item})=><ProviderCard item={item} onPress={()=>navigation.navigate('Provider',{provider:item})}/>} ListEmptyComponent={<Text style={s.empty}>No matching providers found in {location?.city}. Try another category or city.</Text>}/>}
 </View>
}
const s=StyleSheet.create({screen:{flex:1,backgroundColor:'#F6F8F7'},heading:{fontSize:22,fontWeight:'900',color:'#17221D',paddingHorizontal:17,paddingTop:18},filters:{flexDirection:'row',gap:8,padding:16},chip:{paddingHorizontal:13,paddingVertical:9,borderRadius:30,backgroundColor:'#fff',borderWidth:1,borderColor:'#E2EAE5'},active:{backgroundColor:'#087F5B',borderColor:'#087F5B'},chipText:{color:'#526158',fontWeight:'700',fontSize:12},activeText:{color:'#fff'},empty:{color:'#718078',textAlign:'center',padding:30,lineHeight:22}});
