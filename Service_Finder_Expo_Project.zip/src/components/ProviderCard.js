import React from 'react';
import { View, Text, Image, Pressable, StyleSheet } from 'react-native';
import { colors } from '../theme';
export function ProviderCard({item,onPress,compact=false}) {
 return <Pressable onPress={onPress} style={s.card}>
  <Image source={{uri:item.photo || 'https://placehold.co/160x160/png'}} style={s.photo}/>
  <View style={{flex:1}}>
   <View style={s.line}><Text style={s.name}>{item.name}</Text>{item.verified&&<Text style={s.verified}>✓ Verified</Text>}</View>
   <Text style={s.muted}>{item.area} · {item.experience} yrs experience</Text>
   <Text style={s.rating}>★ {Number(item.rating||0).toFixed(1)} <Text style={s.muted}>({item.reviews||0} reviews)</Text></Text>
   {!compact&&<Text style={s.price}>{item.price||'Contact for price'}</Text>}
  </View>
 </Pressable>
}
const s=StyleSheet.create({
 card:{backgroundColor:'#fff',borderRadius:18,padding:12,marginBottom:12,flexDirection:'row',gap:12,borderWidth:1,borderColor:'#E6EDE8'},
 photo:{width:76,height:76,borderRadius:14,backgroundColor:'#E8F5EF'},
 line:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',gap:6},
 name:{fontSize:16,fontWeight:'800',color:'#17221D',flexShrink:1},
 verified:{fontSize:10,color:'#087F5B',fontWeight:'800'},
 muted:{color:'#718078',fontSize:12,marginTop:4},
 rating:{color:'#B7791F',fontWeight:'800',marginTop:6},
 price:{color:'#087F5B',fontWeight:'700',fontSize:12,marginTop:5}
});
