import React from 'react';
import {View,Text,FlatList,StyleSheet} from 'react-native';
import {useApp} from '../context/AppContext';
import {demoProviders} from '../data/demoProviders';
import {ProviderCard} from '../components/ProviderCard';
export function FavouritesScreen({navigation}){
 const {favourites}=useApp();const data=demoProviders.filter(p=>favourites.includes(p.id));
 return <View style={s.screen}><Text style={s.title}>Your favourites</Text><FlatList data={data} keyExtractor={x=>x.id} contentContainerStyle={{padding:16}} renderItem={({item})=><ProviderCard item={item} onPress={()=>navigation.navigate('Provider',{provider:item})}/>} ListEmptyComponent={<Text style={s.empty}>You haven't saved any providers yet. Tap the heart on a provider profile to save it here.</Text>}/>}</View>
}
const s=StyleSheet.create({screen:{flex:1,backgroundColor:'#F6F8F7'},title:{fontSize:23,fontWeight:'900',color:'#17221D',padding:18},empty:{color:'#718078',textAlign:'center',padding:30,lineHeight:22}});
