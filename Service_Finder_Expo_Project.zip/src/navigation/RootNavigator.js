import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Text } from 'react-native';
import { useApp } from '../context/AppContext';
import { LocationFlowScreen } from '../screens/LocationFlowScreen';
import { HomeScreen } from '../screens/HomeScreen';
import { CategoryScreen } from '../screens/CategoryScreen';
import { ProviderScreen } from '../screens/ProviderScreen';
import { ReviewScreen } from '../screens/ReviewScreen';
import { RegisterScreen } from '../screens/RegisterScreen';
import { FavouritesScreen } from '../screens/FavouritesScreen';
import { SettingsScreen } from '../screens/SettingsScreen';

const Stack=createNativeStackNavigator(), Tab=createBottomTabNavigator();
function Tabs(){
 return <Tab.Navigator screenOptions={({route})=>({headerShown:false,tabBarActiveTintColor:'#087F5B',tabBarLabelStyle:{fontWeight:'700'},tabBarIcon:({color})=><Text style={{fontSize:18,color}}>{({Home:'⌂',Favourites:'♡',Settings:'⚙'})[route.name]}</Text>})}>
  <Tab.Screen name="Home" component={HomeScreen}/>
  <Tab.Screen name="Favourites" component={FavouritesScreen}/>
  <Tab.Screen name="Settings" component={SettingsScreen}/>
 </Tab.Navigator>
}
export function RootNavigator(){
 const {location}=useApp();
 return <Stack.Navigator>
  {!location ? <Stack.Screen name="LocationSetup" component={LocationFlowScreen} options={{headerShown:false,gestureEnabled:false}}/> : null}
  <Stack.Screen name="Main" component={Tabs} options={{headerShown:false}}/>
  <Stack.Screen name="Category" component={CategoryScreen} options={{title:'Service providers'}}/>
  <Stack.Screen name="Provider" component={ProviderScreen} options={{title:'Provider profile'}}/>
  <Stack.Screen name="Review" component={ReviewScreen} options={{title:'Write a review'}}/>
  <Stack.Screen name="Register" component={RegisterScreen} options={{title:'Register as provider'}}/>
  <Stack.Screen name="ChangeLocation" component={LocationFlowScreen} options={{headerShown:false}}/>
 </Stack.Navigator>
}
