import React from 'react';
import {View,Text,Pressable,StyleSheet,Switch,Alert,ScrollView} from 'react-native';
import {useApp} from '../context/AppContext';
export function SettingsScreen({navigation}){
 const {language,setLanguage,darkMode,setDarkMode}=useApp();
 const row=(label,action,right)=><Pressable onPress={action} style={s.row}><Text style={s.rowText}>{label}</Text>{right||<Text style={s.arrow}>›</Text>}</Pressable>;
 return <ScrollView style={s.screen}><Text style={s.title}>Settings</Text>
 {row('Change location',()=>navigation.navigate('ChangeLocation'))}
 <View style={s.row}><Text style={s.rowText}>Language</Text><View style={{flexDirection:'row',gap:8}}><Pressable onPress={()=>setLanguage('en')} style={[s.lang,language==='en'&&s.active]}><Text style={[s.langText,language==='en'&&s.activeText]}>English</Text></Pressable><Pressable onPress={()=>setLanguage('ur')} style={[s.lang,language==='ur'&&s.active]}><Text style={[s.langText,language==='ur'&&s.activeText]}>اردو</Text></Pressable></View></View>
 <View style={s.row}><Text style={s.rowText}>Dark mode</Text><Switch value={darkMode} onValueChange={setDarkMode} trackColor={{true:'#087F5B'}}/></View>
 {row('About Service Finder',()=>Alert.alert('Service Finder','Find local professionals and contact them directly.'))}
 {row('Privacy policy',()=>Alert.alert('Privacy policy','Add your published privacy policy URL before releasing the app.'))}
 {row('Contact us',()=>Alert.alert('Contact us','Configure a support email address before publishing.'))}
 <Text style={s.version}>Service Finder · Version 1.0.0</Text>
 </ScrollView>
}
const s=StyleSheet.create({screen:{flex:1,backgroundColor:'#F6F8F7'},title:{fontSize:24,fontWeight:'900',color:'#17221D',padding:18},row:{backgroundColor:'#fff',padding:17,marginHorizontal:16,marginBottom:9,borderRadius:14,flexDirection:'row',justifyContent:'space-between',alignItems:'center',borderWidth:1,borderColor:'#E2EAE5'},rowText:{fontWeight:'700',color:'#26352C'},arrow:{fontSize:23,color:'#087F5B'},lang:{paddingHorizontal:12,paddingVertical:8,borderRadius:20,backgroundColor:'#F1F5F2'},active:{backgroundColor:'#087F5B'},langText:{color:'#526158',fontWeight:'700'},activeText:{color:'#fff'},version:{color:'#87938B',textAlign:'center',margin:28,fontSize:12}});
