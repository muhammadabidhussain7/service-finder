import React,{useEffect,useState} from 'react';
import {View,Text,TextInput,ScrollView,Pressable,StyleSheet,ActivityIndicator} from 'react-native';
import {useApp} from '../context/AppContext';
import {categories} from '../data/categories';
import {getProviders} from '../services/providers';
import {ProviderCard} from '../components/ProviderCard';
import {CategoryTile} from '../components/CategoryTile';

export function HomeScreen({navigation}){
 const {location}=useApp(); const [search,setSearch]=useState(''); const [providers,setProviders]=useState([]); const [loading,setLoading]=useState(true); const [error,setError]=useState('');
 useEffect(()=>{let active=true;(async()=>{try{const p=await getProviders(location?.city);if(active)setProviders(p.sort((a,b)=>b.rating-a.rating).slice(0,4));}catch(e){setError('Could not load providers. Check your internet connection and try again.');}finally{if(active)setLoading(false);}})();return()=>{active=false}},[location]);
 return <ScrollView style={s.screen} contentContainerStyle={s.content}>
  <View style={s.header}><View><Text style={s.hello}>Find trusted help</Text><Pressable onPress={()=>navigation.navigate('ChangeLocation')}><Text style={s.location}>⌖ {location?.city||'Choose location'}⌄</Text></Pressable></View><Pressable style={s.avatar} onPress={()=>navigation.navigate('Settings')}><Text>⚙</Text></Pressable></View>
  <TextInput value={search} onChangeText={setSearch} placeholder="Search plumber, electrician..." style={s.search}/>
  {search.length>0&&<Pressable onPress={()=>navigation.navigate('Category',{search})}><Text style={s.searchAction}>Search for “{search}” →</Text></Pressable>}
  <View style={s.sectionHead}><Text style={s.section}>Explore services</Text><Text style={s.muted}>12 categories</Text></View>
  <View style={s.grid}>{categories.map(c=><CategoryTile key={c.id} item={c} onPress={()=>navigation.navigate('Category',{category:c})}/>)}</View>
  <View style={s.sectionHead}><Text style={s.section}>Top rated near you</Text><Pressable onPress={()=>navigation.navigate('Category')}><Text style={s.link}>See all</Text></Pressable></View>
  {loading?<ActivityIndicator color="#087F5B" style={{margin:25}}/>:error?<Text style={s.muted}>{error}</Text>:providers.length===0?<Text style={s.muted}>No providers listed in this city yet. Be the first to register.</Text>:providers.map(p=><ProviderCard key={p.id} item={p} onPress={()=>navigation.navigate('Provider',{provider:p})}/>)}
  <Pressable style={s.register} onPress={()=>navigation.navigate('Register')}><Text style={s.registerText}>Are you a service professional?  Register now →</Text></Pressable>
 </ScrollView>
}
const s=StyleSheet.create({screen:{flex:1,backgroundColor:'#F6F8F7'},content:{padding:18,paddingBottom:35},header:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:20},hello:{fontSize:23,fontWeight:'900',color:'#17221D'},location:{color:'#087F5B',fontWeight:'800',marginTop:5},avatar:{width:42,height:42,borderRadius:15,backgroundColor:'#E8F5EF',alignItems:'center',justifyContent:'center'},search:{height:52,borderRadius:16,backgroundColor:'#fff',paddingHorizontal:16,borderWidth:1,borderColor:'#E2EAE5',marginBottom:22},searchAction:{color:'#087F5B',marginTop:-14,marginBottom:16,fontWeight:'700'},sectionHead:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:13,marginTop:4},section:{fontSize:18,fontWeight:'900',color:'#17221D'},muted:{color:'#718078',fontSize:12},grid:{flexDirection:'row',flexWrap:'wrap',justifyContent:'space-between'},link:{color:'#087F5B',fontWeight:'800'},register:{padding:17,borderRadius:16,backgroundColor:'#E8F5EF',marginTop:12},registerText:{color:'#087F5B',fontWeight:'800',textAlign:'center'}});
