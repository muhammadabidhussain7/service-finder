import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { I18nManager } from 'react-native';

const Ctx = createContext(null);
const KEY = 'service-finder-settings-v1';
export function AppProvider({children}) {
  const [ready,setReady] = useState(false);
  const [location,setLocation] = useState(null);
  const [language,setLanguage] = useState('en');
  const [darkMode,setDarkMode] = useState(false);
  const [favourites,setFavourites] = useState([]);
  useEffect(() => { (async()=>{
    try {
      const raw = await AsyncStorage.getItem(KEY);
      if (raw) { const v=JSON.parse(raw); setLocation(v.location||null); setLanguage(v.language||'en'); setDarkMode(!!v.darkMode); setFavourites(v.favourites||[]); }
    } catch(e) {} finally { setReady(true); }
  })(); },[]);
  useEffect(() => { if(ready) AsyncStorage.setItem(KEY,JSON.stringify({location,language,darkMode,favourites})).catch(()=>{}); },[ready,location,language,darkMode,favourites]);
  const value = useMemo(()=>({
    ready,location,setLocation,language,setLanguage,darkMode,setDarkMode,favourites,
    toggleFavourite:(id)=>setFavourites(old=>old.includes(id)?old.filter(x=>x!==id):[...old,id]),
    isFavourite:(id)=>favourites.includes(id)
  }),[ready,location,language,darkMode,favourites]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
export const useApp = () => useContext(Ctx);
