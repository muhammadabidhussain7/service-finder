import React,{useState} from 'react';
import {View,Text,TextInput,ScrollView,Pressable,StyleSheet,Alert} from 'react-native';
import {categories} from '../data/categories';
import {useApp} from '../context/AppContext';
import {submitProvider} from '../services/providers';
export function RegisterScreen({navigation}){
 const {location}=useApp();const [form,setForm]=useState({name:'',phone:'',category:'plumber',area:'',experience:'',description:''});const [busy,setBusy]=useState(false);
 const update=(k,v)=>setForm(f=>({...f,[k]:v}));
 const submit=async()=>{if(!form.name||!form.phone||!form.area){Alert.alert('Missing details','Please add your name, phone and area.');return;}setBusy(true);try{await submitProvider({...form,experience:Number(form.experience)||0,city:location?.city||'Karachi'});Alert.alert('Submitted','Your provider profile is pending admin approval.');navigation.goBack();}catch(e){Alert.alert('Registration not submitted',e.message||'Please try again.');}finally{setBusy(false)}};
 const field=(label,key,placeholder,keyboardType='default',multi=false)=><View style={s.field}><Text style={s.label}>{label}</Text><TextInput value={form[key]} onChangeText={v=>update(key,v)} placeholder={placeholder} keyboardType={keyboardType} multiline={multi} style={[s.input,multi&&{height:100,textAlignVertical:'top'}]}/></View>;
 return <ScrollView style={s.screen} contentContainerStyle={{padding:18}}><Text style={s.intro}>Create a profile so customers in {location?.city||'your city'} can find and contact you.</Text>
 {field('Full name','name','Your name')}{field('Phone / WhatsApp','phone','03XXXXXXXXX','phone-pad')}
 <Text style={s.label}>Service category</Text><View style={s.categories}>{categories.map(c=><Pressable key={c.id} onPress={()=>update('category',c.id)} style={[s.chip,form.category===c.id&&s.active]}><Text style={{color:form.category===c.id?'#fff':'#526158',fontWeight:'700'}}>{c.name}</Text></Pressable>)}</View>
 {field('Area','area','e.g. Gulshan-e-Iqbal')}{field('Experience (years)','experience','e.g. 5','numeric')}{field('Short description','description','Describe your services', 'default',true)}
 <Text style={s.note}>New listings are reviewed by an administrator and remain pending until approved. Add your profile photo after Firebase Storage is configured.</Text>
 <Pressable disabled={busy} onPress={submit} style={s.submit}><Text style={{color:'#fff',fontWeight:'900'}}>{busy?'Submitting...':'Submit for approval'}</Text></Pressable>
 </ScrollView>
}
const s=StyleSheet.create({screen:{flex:1,backgroundColor:'#F6F8F7'},intro:{color:'#718078',lineHeight:21,marginBottom:20},field:{marginBottom:14},label:{fontWeight:'800',color:'#17221D',marginBottom:7},input:{backgroundColor:'#fff',borderRadius:13,padding:14,borderWidth:1,borderColor:'#E2EAE5',color:'#17221D'},categories:{flexDirection:'row',flexWrap:'wrap',gap:8,marginBottom:15},chip:{padding:10,borderRadius:20,backgroundColor:'#fff',borderWidth:1,borderColor:'#E2EAE5'},active:{backgroundColor:'#087F5B',borderColor:'#087F5B'},note:{color:'#718078',fontSize:12,lineHeight:18,marginVertical:10},submit:{backgroundColor:'#087F5B',padding:17,borderRadius:14,alignItems:'center',marginBottom:25}});
