import React,{useState} from 'react';
import {View,Text,TextInput,Pressable,StyleSheet,Alert} from 'react-native';
import {collection,addDoc} from 'firebase/firestore';
import {db,firebaseConfigured} from '../services/firebase';
export function ReviewScreen({route,navigation}){
 const p=route.params.provider;const [rating,setRating]=useState(5),[comment,setComment]=useState('');
 const submit=async()=>{if(!comment.trim()){Alert.alert('Add a comment','Please write a short review.');return;}try{if(firebaseConfigured)await addDoc(collection(db,'reviews'),{providerId:p.id,rating,comment:comment.trim(),createdAt:new Date().toISOString()});else Alert.alert('Demo mode','Connect Firebase to publish reviews. Your review has not been uploaded.');navigation.goBack();}catch(e){Alert.alert('Could not submit','Please try again later.')}};
 return <View style={s.screen}><Text style={s.title}>Rate {p.name}</Text><Text style={s.label}>Your rating</Text><View style={s.stars}>{[1,2,3,4,5].map(n=><Pressable key={n} onPress={()=>setRating(n)}><Text style={{fontSize:38,color:n<=rating?'#E6A23C':'#CBD5CE'}}>★</Text></Pressable>)}</View><Text style={s.label}>Your review</Text><TextInput multiline value={comment} onChangeText={setComment} placeholder="Share your experience..." style={s.input}/><Pressable onPress={submit} style={s.submit}><Text style={{color:'#fff',fontWeight:'900'}}>Submit review</Text></Pressable></View>
}
const s=StyleSheet.create({screen:{flex:1,backgroundColor:'#F6F8F7',padding:20},title:{fontSize:24,fontWeight:'900',color:'#17221D',marginBottom:25},label:{fontWeight:'800',color:'#17221D',marginBottom:10},stars:{flexDirection:'row',gap:8,marginBottom:25},input:{height:150,backgroundColor:'#fff',borderRadius:15,padding:15,textAlignVertical:'top',borderWidth:1,borderColor:'#E2EAE5',color:'#17221D'},submit:{backgroundColor:'#087F5B',padding:16,borderRadius:14,alignItems:'center',marginTop:18}});
