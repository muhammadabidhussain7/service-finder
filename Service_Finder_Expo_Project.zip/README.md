# Service Finder — Expo React Native

A cross-platform Android/iOS starter app for discovering local service professionals. English is the default language; an Urdu language preference switch is included as a foundation for full translated/RTL copy.

## Important scope notes

- This is a native Expo source project, not an AppDeploy-hosted website.
- The app runs in **demo mode** using local sample provider data until Firebase is configured.
- Firebase provider listing, provider submission and reviews are wired to Firestore. You must create the Firebase project, configure security rules and add environment values.
- Provider photo upload/picking, production authentication, admin approval dashboard, distance-based sorting and complete Urdu translation are production follow-up tasks; the UI explicitly avoids pretending these are already live.
- Sample provider phone numbers and listings are placeholders. Replace them before release.
- The app does not include an admin account or admin approval UI. New registrations are written with `status: "pending"` and should only be published by a trusted admin process.

## Requirements

- Node.js LTS
- npm
- Expo Go on a physical Android/iOS phone for initial testing
- For store builds: an Expo account, Apple Developer account and Google Play Console account

## Run locally

```bash
npm install
npx expo start
```

Scan the QR code with Expo Go. For an Android emulator use `npx expo start --android`; for iOS Simulator use `npx expo start --ios` on macOS.

## Firebase setup

1. Create a project at https://console.firebase.google.com.
2. Add a Firebase Web App to obtain its public client configuration.
3. Enable Firestore and choose Authentication providers you intend to use (Email/Password or Phone).
4. Copy `.env.example` to `.env` and fill in the `EXPO_PUBLIC_FIREBASE_*` values.
5. Restart Expo after changing environment variables.
6. Create Firestore collections: `providers`, `reviews`, and `users`.
7. Deploy strict Firestore rules. Do not allow public clients to approve providers or arbitrarily edit ratings.

Suggested data model:

- `providers/{providerId}`: `name`, `phone`, `category`, `city`, `area`, `experience`, `description`, `photoUrl`, `status`, `createdAt`, `ownerUid`
- `reviews/{reviewId}`: `providerId`, `rating`, `comment`, `createdAt`, `authorUid`
- `users/{uid}`: `displayName`, `phone`, `email`, `createdAt`

Suggested security policy:
- Public users may read only providers where `status == "approved"`.
- Authenticated users may create their own provider application with `status == "pending"`.
- Only trusted admins (custom claims / server-side role) can change `status` to `approved` or `rejected`.
- Users may create reviews only when authenticated; validate rating 1–5 and prevent self-review/spam in trusted backend logic.
- Never ship admin credentials in the app.

## EAS Build

Install and configure EAS:

```bash
npm install -g eas-cli
eas login
eas build:configure
```

Set your identifiers in `app.json` (`ios.bundleIdentifier` and `android.package`) to identifiers you own.

Android Play Store bundle:

```bash
eas build --platform android --profile production
```

iOS App Store build:

```bash
eas build --platform ios --profile production
```

Add an `eas.json` before production builds, for example:

```json
{
  "build": {
    "development": { "developmentClient": true, "distribution": "internal" },
    "preview": { "distribution": "internal" },
    "production": { "autoIncrement": true }
  }
}
```

EAS will guide you through signing credentials. The Android production artifact is normally an `.aab`; the iOS production artifact is an `.ipa` submitted through App Store Connect.

## Before publishing

- [ ] Replace demo data and sample phone numbers.
- [ ] Add real Firebase project configuration.
- [ ] Add Authentication UI and enforce sign-in for reviews/provider registration.
- [ ] Configure and test Firestore rules and admin approval workflow.
- [ ] Add provider photo picker and Firebase Storage upload.
- [ ] Add complete Urdu translations and RTL layout testing.
- [ ] Implement real distance sorting only after requesting location permission and adding a location strategy.
- [ ] Add privacy policy, support contact and data deletion process.
- [ ] Add app icon, splash artwork, screenshots and store listing metadata.
- [ ] Test on multiple Android and iOS devices, including offline/error states.
- [ ] Complete Google Play Data safety and Apple privacy disclosures.
- [ ] Verify phone and WhatsApp links on physical devices.
- [ ] Run EAS production builds and test release artifacts before submission.
