export const categories = [
  { id:'plumber', name:'Plumber', urdu:'پلمبر', icon:'🔧' },
  { id:'electrician', name:'Electrician', urdu:'الیکٹریشن', icon:'💡' },
  { id:'tutor', name:'Tutor', urdu:'ٹیوٹر', icon:'📚' },
  { id:'mechanic', name:'Mechanic', urdu:'مکینک', icon:'🚗' },
  { id:'carpenter', name:'Carpenter', urdu:'بڑھئی', icon:'🪚' },
  { id:'painter', name:'Painter', urdu:'پینٹر', icon:'🎨' },
  { id:'ac', name:'AC Technician', urdu:'اے سی ٹیکنیشن', icon:'❄️' },
  { id:'cleaner', name:'Cleaning', urdu:'صفائی', icon:'🧹' },
  { id:'tailor', name:'Tailor', urdu:'درزی', icon:'🧵' },
  { id:'computer', name:'Computer Repair', urdu:'کمپیوٹر مرمت', icon:'💻' },
  { id:'gardener', name:'Gardener', urdu:'مالی', icon:'🌿' },
  { id:'other', name:'Other Services', urdu:'دیگر خدمات', icon:'🛠️' }
];
